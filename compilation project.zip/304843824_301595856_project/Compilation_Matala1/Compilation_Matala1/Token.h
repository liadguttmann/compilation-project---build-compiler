#ifndef TOKEN_H
#define TOKEN_H
#include <stdio.h>
#include <stdlib.h>
#include "myParser.h"


extern FILE *yyin, *yyout;

#define block_token 1
#define begin_token 2
#define end_token 3
#define type_token 4
#define is_token 5
#define integer_token 6
#define real_token 7
#define array_token 8
#define of_token 9
#define when_token 10
#define do_token 11
#define default_token 12
#define end_when_token 13
#define for_token 14
#define end_for_token 15
#define malloc_token 16
#define size_of_token 17
#define free_token 18
#define plus_token 19
#define minus_token 20
#define multiplication_token 21
#define division_token 22
#define power_token 23
#define double_plus_token 24
#define assignment_token 25
#define adress_token 26
#define pointerIndicator_token 27
#define biggerOrEqual_token 28
#define smallerOrEqual_token 29
#define biggerThan_token 30
#define smallerThen_token 31
#define different_token 32
#define equal_token 33
#define colon_token 34
#define semicolon_token 35
#define openParentheses_token 36
#define closeParentheses_token 37
#define openBrackets_token 38
#define closeBrackets_token 39
#define id_token 40
#define int_num_token 41
#define real_num_token 42
#define EOF_token 43


typedef enum eTOKENS
{
	TOKEN_INTEGER,
	TOKEN_IF,
	TOKEN_WHILE,
	TOKEN_OP_EQUAL
	/*
		Examples of tokens, add/change according to your needs.
		
		Alternative way to define tokens:
		#define TOKEN_INTEGER 1
		#define TOKEN_IF 2
		...........
	*/
}eTOKENS;

typedef struct Token
{
	eTOKENS kind;
	char *lexeme;
	int lineNumber;
}Token;

typedef struct Node
{
	Token *tokensArray;
	struct Node *prev;
	struct Node *next;
} Node;

void create_and_store_token(eTOKENS kind, char* lexeme, int numOfLine);
Token *next_token();
Token *back_token();
void initialzation_list();

Token* get_first_token();


#endif