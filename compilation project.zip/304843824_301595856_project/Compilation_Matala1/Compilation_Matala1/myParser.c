#include "Token.h"
#include "myParser.h"
#include "linkedList.h"
#include <string.h>
#include <stdarg.h> 

void printSymanticErrors(Token* currToken , char *errorMsg,...);
void printErrorsToken(char *str , Token* currToken);
void Parser_Reciver_Tagaim(Token* currToken, typeDATA id_data);

char* globalCurrName[0x50];
int gCurrentScope = 0;
typeNODE* gTypeLinkedList = NULL;
int gPrintFlag;

void addType(char* typeName, int idType, int idTypeType, int idScope)
{
	typeDATA data;
	int stringLength = strlen(typeName);
	data.idName = (char *)malloc(stringLength);
	strcpy(data.idName, typeName);
	data.idType = idType;
	data.idTypeType = idTypeType;
	data.idScope = idScope;
	if (gTypeLinkedList)
	{
		gTypeLinkedList = add(gTypeLinkedList, data);
	}
	else
	{
		gTypeLinkedList = init(data);
	}
}

int findType(char* typeName, typeDATA* outData)
{
	typeDATA data;
	typeNODE* currentNode = gTypeLinkedList;
	while (currentNode != NULL)
	{
		if (!strcmp(currentNode->data.idName, typeName))
		{
			outData->idName = (char*)malloc(strlen(currentNode->data.idName));
			strcpy(outData->idName, currentNode->data.idName);
			outData->idType = currentNode->data.idType;
			outData->idTypeType = currentNode->data.idTypeType;
			outData->idScope = currentNode->data.idScope;
			// return 1 means, we found the id name
			return 1;
		}
		currentNode = currentNode->next;
	}
	// return 0 means, we have not found the id name
	return 0;
}

int findTypeWithScope(char* typeName, int scope, typeDATA* outData)
{
	typeDATA data;
	typeNODE* currentNode = gTypeLinkedList;
	while (currentNode != NULL)
	{
		if ((currentNode->data.idScope == scope) && !strcmp(currentNode->data.idName, typeName))
		{
			outData->idName = (char*)malloc(strlen(currentNode->data.idName));
			strcpy(outData->idName, currentNode->data.idName);
			outData->idType = currentNode->data.idType;
			outData->idTypeType = currentNode->data.idTypeType;
			outData->idScope = currentNode->data.idScope;
			// return 1 means, we found the id name
			return 1;
		}
		currentNode = currentNode->next;
	}
	// return 0 means, we have not found the id name
	return 0;
}

int removeScope(int scope)
{
	typeDATA data;
	typeNODE* currentNode = gTypeLinkedList;
	while (currentNode != NULL)
	{
		if (currentNode->data.idScope == scope)
		{
			removeNode(currentNode);
		}
		currentNode = currentNode->next;
	}
	// return 0 means, we have not found the id name
	return 0;
}




int match(int token_Kind)
{
	Token* currToken = NULL;
	currToken = next_token();
	if(currToken == NULL)
	{
		printf("error end of tokens");
		return 0;
	}
	if(token_Kind != currToken->kind)
	{
//		fprintf(yyout , "Expected token %d at line: %d,\nActuall token '%d', lexeme: '%s'.\n", token_Kind , currToken->lineNumber , currToken->kind , currToken->lexeme);
		return 0;
	}
	else
	{
		return 1;
	}
}

void myParserMain(int printFlag)
{
	int followArray[1] = {EOF_token};
	int followArraySize = 1;
	int index = 0;
	Token* currToken = NULL;
	char* lexeme = NULL;
	int kind = 0;
	int lineNumber = 0;
	int i = 0;
	
	gPrintFlag = printFlag;
	addType("integer", idTypeOfType, idTypeTypeInteger, gCurrentScope);
	addType("real", idTypeOfType, idTypeTypeReal, gCurrentScope);

	currToken = get_first_token();
	if(currToken == NULL)
	{
		return;
	}
	kind = currToken->kind;
	
	if(kind == block_token)
	{
		printTheRule(" PROGRAM -> BLOCK");
		Parser_Block(1);
	}
	else
	{
		printErrorsToken("BLOCK" , currToken);
		recoveryFromError(followArray, followArraySize);
	}
	/*
	currToken = next_token();
	if(currToken == NULL)
	{
		return;
	}
	kind = currToken->kind;

	if(kind == begin_token)
	{
		Parser_Begin();
	}
	else
	{
		printErrorsToken("begin" , currToken);
		recoveryFromError(followArray, followArraySize);
	}
	*/
}


void Parser_Block(int isStart)
{
	int followArray[1] = {end_token};
	int followArraySize = 1;
	Token* currToken = NULL;
	int kind = 0;

	if (isStart)
	{
		followArray[0] = EOF_token;
	}
	gCurrentScope++;

	printTheRule("BLOCK -> block DEFINITIONS; begin COMMANDS; end");
	Parser_Definitions();

	currToken = next_token();
	if(currToken == NULL)
	{
		return;
	}
	kind = currToken->kind;

	if(kind == begin_token)
	{
		Parser_Begin();
	}
	else
	{
		printErrorsToken("begin" , currToken);
		recoveryFromError(followArray, followArraySize);
	}

	removeScope(gCurrentScope);
	gCurrentScope--;
}

void Parser_Definition()
{
	int followArray[1] = {semicolon_token};
	int followArraySize = 1;
	int kind = 0;
	Token* currToken = next_token();
	kind = currToken->kind;
	if (kind == id_token)
	{
		printTheRule("DEFINITION -> VAR_DEFINITION ");
		Parser_Var_Definition(currToken->lexeme);
	}
	else if (kind == type_token)
	{
		printTheRule("DEFINITION -> TYPE_DEFINITION ");
		Parser_Type_Definition();
	}
	else
	{
		printErrorsToken("id_token | type_token " , currToken);
		recoveryFromError(followArray, followArraySize);
	}
	
}


void Parser_Definitions()
{
	int followArray[1] = {semicolon_token};
	int followArraySize = 1;
	int kind = 0;
	//Token* currToken = 0;
	Token* currToken = next_token();
	kind = currToken->kind;
	while (kind != begin_token)
	{
		back_token();
		printTheRule("DEFINITION -> DEFINITION  DEFINITIONS' ");
		Parser_Definition();
		currToken = next_token();
		kind = currToken->kind;
	}
	back_token();
}

void Parser_Var_Definition(char* id_name)
{
	int followArray[1] = {semicolon_token};
	int followArraySize = 1;
	int kind = 0;
	Token* currToken = next_token();
	if(currToken == NULL)
	{
		return;
	}
	kind = currToken->kind;
	if(kind != colon_token)
	{
		printErrorsToken("colon_token" , currToken);
		recoveryFromError(followArray, followArraySize);
	}
	printTheRule("VAR_DEFINITION -> id: VAR_DEFINITION' ");
	Parser_Var_Definition_Tag(id_name);
}

void Parser_Var_Definition_Tag(char* id_name)
{
	int followArray[1] = {semicolon_token};
	int followArraySize = 1;
	int kind = 0;
	char* var_type_name;
	typeDATA data;
	Token* currToken = next_token();
	if(currToken == NULL)
	{
		return;
	}
	kind = currToken->kind;
	var_type_name = currToken->lexeme;

	if(kind == id_token)
	{
		printTheRule("VAR_DEFINITION'-> type_name ");
		if(findType(var_type_name, &data))
		{
			if (data.idType == idTypeOfType)
			{
				addType(id_name, idTypeOfVar, data.idTypeType, gCurrentScope);
			}
			else
			{
				printSymanticErrors(currToken , "Expected %s to be defined as type and not as var in this block", var_type_name);
			}
		}
		else
		{
			printSymanticErrors(currToken , "type %s is not defined", var_type_name);
		}

		currToken = next_token();
		if(currToken == NULL)
		{
			return;
		}
		kind = currToken->kind;
		if (kind != semicolon_token)
		{
			printErrorsToken("semicolon_token" , currToken);
			recoveryFromError(followArray, followArraySize);
		}
	}
	else
	{
		back_token();
		printTheRule("VAR_DEFINITION'-> BASIC_TYPE  ");
		Parser_Basic_Type(id_name, prevTypeVar);
	}
}

void Parser_Type_Definition()
{
	int followArray[1] = {semicolon_token};
	int followArraySize = 1;
	int kind = 0;
	char* type_name;
	Token* currToken = next_token();
	if(currToken == NULL)
	{
		return;
	}
	kind = currToken->kind;
	if(kind != id_token)
	{
		printErrorsToken("id_token" , currToken);
		recoveryFromError(followArray, followArraySize);
	}

	
	type_name = currToken->lexeme;

	currToken = next_token();
	if(currToken == NULL)
	{
		return;
	}
	kind = currToken->kind;
	if(kind != is_token)
	{
		printErrorsToken("is_token" , currToken);
		recoveryFromError(followArray, followArraySize);
	}
	printTheRule("TYPE_DEFINITION -> type type_name is TYPE_INDICATOR");
	Parser_Type_Indicator(type_name);
}

void Parser_Type_Indicator(char* type_name)
{
	int followArray[1] = {semicolon_token};
	int followArraySize = 1;
	int kind = 0;
	Token* currToken = next_token();
	if(currToken == NULL)
	{
		return;
	}
	kind = currToken->kind;
	switch(kind)
	{
	case array_token:
		printTheRule("TYPE_INDICATOR-> ARRAY_TYPE");
		Parser_Array_Type(type_name);
		break;
	case pointerIndicator_token:
		printTheRule("TYPE_INDICATOR-> POINTER_TYPE");
		Parser_Pointer_Type(type_name);
		break;
	default:
		back_token();
		printTheRule("TYPE_INDICATOR-> BASIC_TYPE ");
		Parser_Basic_Type(type_name, prevTypeNone);
	}
	
}

void Parser_Basic_Type(char* type_name, int prevType)
{
	int followArray[1] = {semicolon_token};
	int followArraySize = 1;
	int kind = 0;
	int idTypeType;
	int idType;
	typeDATA data;
	Token* currToken = next_token();
	if(currToken == NULL)
	{
		return;
	}
	idType = idTypeOfType;
	kind = currToken->kind;
	switch(kind)
	{
	case integer_token:
		printTheRule("BASIC_TYPE -> inteager ");
		currToken = next_token();
		if(currToken == NULL)
		{
			return;
		}
		kind = currToken->kind;
		if (kind != semicolon_token)
		{
			printErrorsToken("semicolon_token" , currToken);
			recoveryFromError(followArray, followArraySize);
		}
		if(!findTypeWithScope(type_name, gCurrentScope, &data))
		{
			if (prevType == prevTypeNone)
			{
				idTypeType = idTypeTypeInteger;
			}
			else if (prevType == prevTypePointer)
			{
				idTypeType = idTypeTypePointerInteger;
			}
			else if (prevType == prevTypeArray)
			{
				idTypeType = idTypeTypeArrayInteger;
			}
			else
			{
				idTypeType = idTypeTypeInteger;
				idType = idTypeOfVar;
			}
			addType(type_name, idType, idTypeType, gCurrentScope);
		}
		else
		{
			printSymanticErrors(currToken , "The %s is already defined in this block", type_name);
		}
		break;
	case real_num_token:
		printTheRule("BASIC_TYPE -> real ");
		currToken = next_token();
		if(currToken == NULL)
		{
			return;
		}
		kind = currToken->kind;
		if (kind != semicolon_token)
		{
			printErrorsToken("semicolon_token" , currToken);
			recoveryFromError(followArray, followArraySize);
		}
		if(!findTypeWithScope(type_name, gCurrentScope, &data))
		{
			if (prevType == prevTypeNone)
			{
				idTypeType = idTypeTypeReal;
			}
			else if (prevType == prevTypePointer)
			{
				idTypeType = idTypeTypePointerReal;
			}
			else if (prevType == prevTypeArray)
			{
				idTypeType = idTypeTypeArrayReal;
			}
			else
			{
				idTypeType = idTypeTypeArrayReal;
				idType = idTypeOfVar;
			}
			addType(type_name, idType, idTypeType, gCurrentScope);
		}
		else
		{
			printSymanticErrors(currToken , "The %s is already defined in this block", type_name);
		}
		break;
	default:
		printErrorsToken("real_num_token | integer_token " , currToken);
		recoveryFromError(followArray, followArraySize);
		break;
	}
}

void Parser_Array_Type(char* type_name)
{
	int followArray[1] = {semicolon_token};
	int followArraySize = 1;
	int kind = 0;
	Token* currToken = next_token();
	if(currToken == NULL)
	{
		return;
	}
	kind = currToken->kind;
	if (kind != openBrackets_token)
	{
		printErrorsToken("openBrackets_token " , currToken);
		recoveryFromError(followArray, followArraySize);
		return;
	}
	printTheRule("SIZE -> int_num");
	if (Parser_Size() != 0)
	{
		return;
	}
	currToken = next_token();
	if(currToken == NULL)
	{
		return;
	}
	kind = currToken->kind;
	if (kind != closeBrackets_token)
	{
		printErrorsToken("closeBrackets_token " , currToken);
		recoveryFromError(followArray, followArraySize);
		return;
	}

	currToken = next_token();
	if(currToken == NULL)
	{
		return;
	}
	kind = currToken->kind;
	if (kind != of_token)
	{
		printErrorsToken("of_token " , currToken);
		recoveryFromError(followArray, followArraySize);
		return;
	}
	
	printTheRule("ARRAY_TYPE  -> array [SIZE] of BASIC_TYPE  ");
	//back_token();
	Parser_Basic_Type(type_name, prevTypeArray);
}

void Parser_Pointer_Type(char* type_name)
{
	int followArray[1] = {semicolon_token};
	int followArraySize = 1;
	int kind = 0;
	char* pointer_type_name;
	typeDATA data;
	Token* currToken = next_token();
	if(currToken == NULL)
	{
		return;
	}
	kind = currToken->kind;
	if (kind == id_token)
	{
		printTheRule("POINTER_TYPE' -> type_name");
		pointer_type_name = currToken->lexeme;
		
		if(findType(pointer_type_name, &data))
		{
			if (data.idType == idTypeOfType)
			{
				addType(type_name, idTypeOfType, data.idTypeType, gCurrentScope);
			}
			else
			{
				printSymanticErrors(currToken , "Expected %s to be defined as type and not as var in this block", pointer_type_name);
			}
		}
		else
		{
			printSymanticErrors(currToken , "%s is not defined at all", pointer_type_name);
		}

		currToken = next_token();
		if(currToken == NULL)
		{
			return;
		}
		kind = currToken->kind;
		if (kind != semicolon_token)
		{
			printErrorsToken("semicolon_token" , currToken);
			recoveryFromError(followArray, followArraySize);
		}
		return;
	}
	else
	{
		printTheRule("POINTER_TYPE' -> BASIC_TYPE ");
		back_token();
		Parser_Basic_Type(type_name, prevTypePointer);
	}
}

int Parser_Size()
{
	int followArray[1] = {closeBrackets_token};
	int followArraySize = 1;
	int kind = 0;
	Token* currToken = next_token();
	if(currToken == NULL)
	{
		return -1;
	}
	kind = currToken->kind;
	if (kind != int_num_token)
	{
		printErrorsToken("int_num_token" , currToken);
		recoveryFromError(followArray, followArraySize);
		return -1;
	}
	return 0;
}

void Parser_Commands()
{
	int followArray[1] = {semicolon_token};
	int followArraySize = 1;
	int kind = 0;
	Token* currToken = next_token();
	kind = currToken->kind;
	while (1)
	{
		back_token();
		printTheRule("COMMANDS -> COMMAND  COMMANDS' ");
		Parser_Command();
		currToken = next_token();
		if(currToken == NULL)
		{
			break;
		}
		kind = currToken->kind;
		if((kind == end_for_token) || (kind == end_when_token) || (kind == default_token))
		{
			break;
		}
		else if(kind == end_token)
		{
			currToken = next_token();
			if(currToken == NULL)
			{
				break;
			}
			kind = currToken->kind;
			if(kind == semicolon_token)
			{
				break;
			}
		}
	}
	back_token();
}

void Parser_Command()
{
	int followArray[1] = {semicolon_token};
	int followArraySize = 1;
	int kind = 0;
	int ret = 0;
	Token* currToken = next_token();
	char* id_name;
	typeDATA id_data;
	int idTypeTypeWhen = 0;
	if(currToken == NULL)
	{
		return;
	}
	kind = currToken->kind;
	switch (kind) 
	{
		case id_token:
		{
			printTheRule("COMMAND ->RECEIVER ");
			id_name = currToken->lexeme;
			if(findType(id_name, &id_data))
			{
				if(id_data.idType != idTypeOfVar)
				{
					printSymanticErrors(currToken , "Expected %s to be defined as var and not as type", id_name);
				}
			}
			else
			{
				printSymanticErrors(currToken , "type %s is not defined", id_name);
			}

			Parser_Reciver(id_data);
			break;
		}
		case when_token:
		{
			printTheRule("COMMAND ->when (EXPRESSION rel_op EXPRESSION) do COMMANDS;default COMMANDS; end_when");
			if(!match(openParentheses_token))
			{
				printErrorsToken("openParentheses_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}

			idTypeTypeWhen = Parser_Expression(0);
			if (Parser_rel_op() != 0)
			{
				break;
			}
			Parser_Expression(idTypeTypeWhen);

			
			if(!match(closeParentheses_token))
			{
				printErrorsToken("closeParentheses_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}

			if(!match(do_token))
			{
				printErrorsToken("do_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}

			// start new scope for do block
			//gCurrentScope++;

			Parser_Commands();

			// end scope for do block
			//gCurrentScope--;

			if(!match(default_token))
			{
				printErrorsToken("default_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}

			// start new scope for default block
			//gCurrentScope++;

			Parser_Commands();

			// end scope for default block
			//gCurrentScope--;


			if(!match(end_when_token))
			{
				printErrorsToken("end_when_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}
			break;
			/*
			if(!match(semicolon_token))
			{
				printErrorsToken("semicolon_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}
			*/
		}
		case for_token:
		{
			printTheRule("COMMAND -> for (id = EXPRESSION; id rel_op EXPRESSION; id++) COMMANDS; end_for ");
			if(!match(openParentheses_token))
			{
				printErrorsToken("openParentheses_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}

			if(!match(id_token))
			{
				printErrorsToken("id_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}

			back_token();
			currToken = next_token();
			if(findType(currToken->lexeme, &id_data))
			{
				if(id_data.idType != idTypeOfVar)
				{
					printSymanticErrors(currToken , "Expected %s to be defined as var and not as type", currToken->lexeme);
				}
				else
				{
					if(id_data.idTypeType != idTypeTypeInteger)
					{
						printSymanticErrors(currToken , "for expected id int %s is not int", currToken->lexeme);
					}
				}
			}
			else
			{
				printSymanticErrors(currToken , "type %s is not defined", currToken->lexeme);
			}

			if(!match(assignment_token))
			{
				printErrorsToken("assignment_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}

			Parser_Expression(idTypeTypeInteger);

			if(!match(semicolon_token))
			{
				printErrorsToken("semicolon_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}

			if(!match(id_token))
			{
				printErrorsToken("id_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}

			back_token();
			currToken = next_token();
			if(findType(currToken->lexeme, &id_data))
			{
				if(id_data.idType != idTypeOfVar)
				{
					printSymanticErrors(currToken , "Expected %s to be defined as var and not as type", currToken->lexeme);
				}
				else
				{
					if(id_data.idTypeType != idTypeTypeInteger)
					{
						printSymanticErrors(currToken , "for expected id int %s is not int", currToken->lexeme);
					}
				}
			}
			else
			{
				printSymanticErrors(currToken , "type %s is not defined", currToken->lexeme);
			}

			if (Parser_rel_op() != 0)
			{
				break;
			}

			Parser_Expression(idTypeTypeInteger);

			if(!match(semicolon_token))
			{
				printErrorsToken("semicolon_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}

			if(!match(id_token))
			{
				printErrorsToken("id_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}

			back_token();
			currToken = next_token();
			if(findType(currToken->lexeme, &id_data))
			{
				if(id_data.idType != idTypeOfVar)
				{
					printSymanticErrors(currToken , "Expected %s to be defined as var and not as type", currToken->lexeme);
				}
				else
				{
					if(id_data.idTypeType != idTypeTypeInteger)
					{
						printSymanticErrors(currToken , "for expected id int %s is not int", currToken->lexeme);
					}
				}
			}
			else
			{
				printSymanticErrors(currToken , "type %s is not defined", currToken->lexeme);
			}

			if(!match(double_plus_token))
			{
				printErrorsToken("double_plus_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}

			if(!match(closeParentheses_token))
			{
				printErrorsToken("closeParentheses_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}

			// start new scope for "for" block
			//gCurrentScope++;

			Parser_Commands();

			// end scope for "for" block
			//gCurrentScope--;

			if(!match(end_for_token))
			{
				printErrorsToken("end_for_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}

			/*
			if(!match(semicolon_token))
			{
				printErrorsToken("semicolon_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}
			*/
			break;
		}
		case free_token:
		{
			printTheRule("COMMAND -> free(id)");
			if(!match(openParentheses_token))
			{
				printErrorsToken("openParentheses_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}

			if(!match(id_token))
			{
				printErrorsToken("id_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}

			if(!match(closeParentheses_token))
			{
				printErrorsToken("closeParentheses_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}
			break;
		}
		case block_token:
		{
			printTheRule("COMMAND -> BLOCK");
			Parser_Block(0);
			break;
		}
		default:
		{
			printErrorsToken("block_token | free_token | for_token | when_token | id_token " , currToken);
			recoveryFromError(followArray, followArraySize);
			break;
		}
	}
	if(!match(semicolon_token))
	{
		printErrorsToken("semicolon_token" , currToken);
		recoveryFromError(followArray, followArraySize);
	}
}

void Parser_Reciver(typeDATA id_data)
{
	printTheRule("RECEIVER -> id RECIVER'");
	Parser_Reciver_Tag(id_data);
}

void Parser_Reciver_Tag(typeDATA id_data)
{
	int followArray[3] = {openBrackets_token , pointerIndicator_token ,assignment_token};
	int followArraySize = 3;
	int kind = 0;
	int idTypeTypePointer;


	Token* currToken = next_token();
	if (currToken == NULL)
	{
		return;
	}
	kind = currToken->kind;
	switch(kind)
	{
		case openBrackets_token:
		{
			printTheRule("RECEIVER' -> [EXPRESSION]  = EXPRESSION ");
			Parser_Expression(idTypeTypeInteger);

			if(!match(closeBrackets_token))
			{
				printErrorsToken("closeBrackets_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}

			if(!match(assignment_token))
			{
				printErrorsToken("assignment_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}

			Parser_Expression(id_data.idTypeType);
			break;
		}
		case pointerIndicator_token:
		{
			printTheRule("RECEIVER' ->  ^ = EXPRESSION");
			if(!match(assignment_token))
			{
				printErrorsToken("assignment_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}
			if (id_data.idTypeType == idTypeTypePointerInteger)
			{
				idTypeTypePointer = idTypeTypeInteger;
			}
			else if (id_data.idTypeType == idTypeTypePointerReal)
			{
				idTypeTypePointer = idTypeTypeReal;
			}
			else
			{
				back_token();
				currToken = next_token();
				printSymanticErrors(currToken , "can not pointer this type");
				idTypeTypePointer = 0;
			}
			Parser_Expression(idTypeTypePointer);
			break;
		}
		case assignment_token:
		{
			printTheRule("RECEIVER' -> = RECEIVER'' ");
			Parser_Reciver_Tagaim(currToken, id_data);
			break;
		}
		default:
		{
			printErrorsToken("assignment_token | pointerIndicator_token | openBrackets_token  " , currToken);
			recoveryFromError(followArray, followArraySize);
			break;
		}
	}	
}

void Parser_Reciver_Tagaim(Token* currToken, typeDATA id_data)
{
	int followArray[1] = {semicolon_token};
	int followArraySize = 1;
	typeDATA data;

	if(!match(malloc_token))
	{
		printTheRule("RECEIVER''-> malloc(size_of(type_name))  | EXPRESSION");
		back_token();
		Parser_Expression(id_data.idTypeType);
		return;
	}

	// Here is the malloc case
	if((id_data.idTypeType == idTypeTypeArrayInteger) || (id_data.idTypeType == idTypeTypeArrayInteger))
	{
		back_token();
		currToken = next_token();
		printSymanticErrors(currToken , "assignment to array is forbidden");
	}

	if(!match(openParentheses_token))
	{
		printErrorsToken("openParentheses_token" , currToken);
		recoveryFromError(followArray, followArraySize);
		return;
	}

	if(!match(size_of_token))
	{
		printErrorsToken("size_of_token" , currToken);
		recoveryFromError(followArray, followArraySize);
		return;
	}

	if(!match(openParentheses_token))
	{
		printErrorsToken("openParentheses_token" , currToken);
		recoveryFromError(followArray, followArraySize);
		return;
	}

	if(!match(id_token))
	{
		printErrorsToken("id_token" , currToken);
		recoveryFromError(followArray, followArraySize);
		return;
	}

	back_token();
	currToken = next_token();
	if(findType(currToken->lexeme, &data))
	{
		if(data.idType != idTypeOfType)
		{
			printSymanticErrors(currToken , "Expected %s to be defined as type and not as var", currToken->lexeme);
		}
	}
	else
	{
		printSymanticErrors(currToken , "type %s is not defined", currToken->lexeme);
	}


	if(!match(closeParentheses_token))
	{
		printErrorsToken("closeParentheses_token" , currToken);
		recoveryFromError(followArray, followArraySize);
		return;
	}

	if(!match(closeParentheses_token))
	{
		printErrorsToken("closeParentheses_token" , currToken);
		recoveryFromError(followArray, followArraySize);
		return;
	}
}


int Parser_Expression(int expectedType)
{
	int followArray[2] = {semicolon_token, closeBrackets_token };
	int followArraySize = 2;
	int kind = 0;
	int checkPointer = 0;
	typeDATA data;
	int determinedType = 0;

	Token* currToken = next_token();
	if (currToken == NULL)
	{
		return -1;
	}
	kind = currToken->kind;
	switch(kind)
	{
		case int_num_token:
			if (expectedType == 0)
			{
				determinedType = idTypeTypeInteger;
			}
			else if (expectedType != idTypeTypeInteger)
			{
				printSymanticErrors(currToken , "NOT expected integer in the expression\n");
			}
			printTheRule("EXPRESSION -> int_num  |  real_num  ");
			break;
		case real_num_token:
			if (expectedType == 0)
			{
				determinedType = idTypeTypeReal;
			}
			else if (expectedType != idTypeTypeReal)
			{
				printSymanticErrors(currToken , "NOT expected real in the expression\n");
			}
			printTheRule("EXPRESSION -> int_num  |  real_num  ");
			break;
		
		case adress_token:
			printTheRule("EXPRESSION -> &id ");
			if(!match(id_token))
			{
				printErrorsToken("id_token" , currToken);
				recoveryFromError(followArray, followArraySize);
			}

			back_token();
			currToken = next_token();
			if(findType(currToken->lexeme, &data))
			{
				if(data.idType != idTypeOfVar)
				{
					printSymanticErrors(currToken , "Expected %s to be defined as var and not as type", currToken->lexeme);
				}
				else
				{
					if (expectedType == 0)
					{
						if(data.idTypeType == idTypeTypeInteger)
						{
							determinedType = idTypeTypePointerInteger;
						}
						else if(data.idTypeType == idTypeTypeReal)
						{
							determinedType = idTypeTypePointerReal;
						}
						else
						{
							printSymanticErrors(currToken , "pointer expression error");
						}
					}
					else if( !(((data.idTypeType == idTypeTypeInteger) && (expectedType == idTypeTypePointerInteger)) || ((data.idTypeType == idTypeTypeReal) && (expectedType == idTypeTypePointerReal))) )
					{
						printSymanticErrors(currToken , "mismatch between types of the left and the right sides of the assignment");
					}
				}
			}
			else
			{
				printSymanticErrors(currToken , "type %s is not defined", currToken->lexeme);
			}

			break;
		case size_of_token:
			printTheRule("EXPRESSION -> size_of(type_name)");
			if(!match(openParentheses_token))
			{
				printErrorsToken("openParentheses_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}

			if(!match(id_token))
			{
				printErrorsToken("id_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}
			
			back_token();
			currToken = next_token();
			if(findType(currToken->lexeme, &data))
			{
				if(data.idType != idTypeOfType)
				{
					printSymanticErrors(currToken , "Expected %s to be defined as type and not as var", currToken->lexeme);
				}
				else
				{
					if(expectedType != idTypeTypeInteger)
					{
						printSymanticErrors(currToken , "size_of expected int assignment");
					}
				}
			}
			else
			{
				printSymanticErrors(currToken , "type %s is not defined", currToken->lexeme);
			}


			if(!match(closeParentheses_token))
			{
				printErrorsToken("closeParentheses_token" , currToken);
				recoveryFromError(followArray, followArraySize);
				break;
			}

			if(expectedType == 0)
			{
				determinedType = idTypeTypeInteger;
			}

			break;
		case id_token:
			printTheRule("EXPRESSION -> id EXPRESSION'");
			
			back_token();
			currToken = next_token();
			if(findType(currToken->lexeme, &data))
			{
				if(data.idType != idTypeOfVar)
				{
					printSymanticErrors(currToken , "Expected %s to be defined as var and not as type", currToken->lexeme);
				}
				else
				{
					if(expectedType == 0)
					{
						if(data.idTypeType == idTypeTypePointerInteger)
						{
							expectedType = idTypeTypeInteger;
						}
						else if (data.idTypeType == idTypeTypePointerReal)
						{
							expectedType = idTypeTypeReal;
						}
						else
						{
							expectedType = data.idTypeType;
						}
						determinedType = expectedType;
					}
					if(((expectedType == idTypeTypeInteger) && (data.idTypeType == idTypeTypePointerInteger)) || ((expectedType == idTypeTypeReal) && (data.idTypeType == idTypeTypePointerReal)))
					{
						checkPointer = 1;
					}
					else if(data.idTypeType != expectedType)
					{
						printSymanticErrors(currToken , "mismatch type of %s", currToken->lexeme);
					}
				}
			}
			else
			{
				printSymanticErrors(currToken , "type %s is not defined", currToken->lexeme);
			}

			Parser_Expression_Tag(expectedType, checkPointer);

			break;
		default:
			printErrorsToken("id_token | size_of_token | adress_token | int_num_token | real_num_token" , currToken);
			recoveryFromError(followArray, followArraySize);		   
			break;
	}
	return determinedType;
}

void Parser_Expression_Tag(int expectedType, int checkPointer)
{
	int followArray[2] = {semicolon_token, closeBrackets_token};
	int followArraySize = 2;
	int kind = 0;
	Token* currToken = next_token();
	if (currToken == NULL)
	{
		return;
	}
	kind = currToken->kind;
	switch(kind)
	{
		case openBrackets_token:
			printTheRule("EXPRESSION' -> [EXPRESSION] ");
			// We send idTypeTypeInteger because it's expression 
			// inside brackets array
			Parser_Expression(idTypeTypeInteger);
			if(!match(closeBrackets_token))
			{
				printErrorsToken("closeParentheses_token" , currToken);
				recoveryFromError(followArray, followArraySize);
			}
			break;
		case pointerIndicator_token:
			if(!checkPointer)
			{
				printSymanticErrors(currToken , "pointer error");
			}
			printTheRule("EXPRESSION' -> ^ ");
			break;
		case plus_token :
		case minus_token:
		case multiplication_token:
		case division_token:
		case power_token:
			printTheRule("EXPRESSION' -> ar_op EXPRESSION");
			Parser_Expression(expectedType);
			break;
		default:
			//printErrorsToken("power_token | division_token | multiplication_token | minus_token | plus_token | pointerIndicator_token " , currToken);
			//recoveryFromError(followArray, followArraySize);
			back_token();
			break;
	}

}

void recoveryFromError(int* followTokenKindArray, int followTokenKindArraySize)
{
	int i = 0;
	Token* currToken;
	while (1)
	{
		currToken = next_token();
		if (currToken == NULL)
		{
			return;
		}
		for(i = 0; i < followTokenKindArraySize; i++)
		{
			if (currToken->kind == followTokenKindArray[i])
			{
				return;
			}
		}
	}
}


void Parser_Begin()
{
	Parser_Commands();
}

int Parser_rel_op()
{
	int followArray[1] = {semicolon_token};
	int followArraySize = 1;
	int kind = 0;
	Token* currToken = NULL;
	currToken = next_token();
	if(currToken == NULL)
	{
		return -1;
	}
	kind = currToken ->kind;
	switch (kind)
	{
		case biggerOrEqual_token:
		case smallerOrEqual_token:
		case biggerThan_token:
		case smallerThen_token:
		case different_token:
		case equal_token:
			return 0;
		default:
			recoveryFromError(followArray, followArraySize);
			return -1;
	}
}
void printTheRule(char *str)
{
	if(gPrintFlag == 2)
	{
	fprintf(yyout , "{%s}\n", str);
	}
}

void printErrorsToken(char *str , Token* currToken)
{
	if(gPrintFlag == 2)
	{
	fprintf(yyout , "Expected token %s at line: %d,\nActuall token '%d', lexeme: '%s'.\n", str , currToken->lineNumber , currToken->kind , currToken->lexeme);
	}
}

void printSymanticErrors(Token* currToken , char *errorMsg,...)
{    
	if(gPrintFlag ==3)
	{
	char errorMessage[1024];
	va_list args;
    va_start(args, errorMsg);
	vsnprintf(errorMessage, 1023, errorMsg, args);
    //sprintf_s(errorMessage, 1024, errorMsg, *args);
	va_end(args);
	fprintf(yyout , "(line: %d): %s\n" , currToken->lineNumber , errorMessage);
	}
}




