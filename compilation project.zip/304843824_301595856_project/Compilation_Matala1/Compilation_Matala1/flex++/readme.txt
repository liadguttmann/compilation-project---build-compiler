flex++ 2.3.8-7 and bison++1.12-8
================================
                              by Kohsuke KAWAGUCHI (kk@kohsuke.org)

This package contains pre-compiled flex++ and bison++ for Win32 platform,
which were compiled by Visual C++ 6.0.

INSTALLATION
------------

    Just extract the whole zip file into a directory, and set PATH env.
    variable so that the system can find them.
    
    Enjoy!


WIN32-SPECIFIC FUNCTIONALITY
----------------------------
    I modified the source code so that skeleton files (bison.cc,
    bison.h, flexskel.cc, and flexskel.h) will be loaded from the
    diretory where bison++/flex++ are in.


SOURCE CODE
-----------
    To play with the source code, download it from:
    http://www.kohsuke.org/flex++bison++/flex++bison++.src.zip
