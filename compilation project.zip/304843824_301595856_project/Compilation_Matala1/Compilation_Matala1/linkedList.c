#include <stdio.h>
#include <stdlib.h>
#include "linkedList.h"



typeNODE* init(typeDATA data) {
    typeNODE* temp = (typeNODE*) malloc(sizeof (typeNODE));
    if (temp == NULL) {
        exit(0); // no memory available
    }
    temp->data = data;
    temp->next = NULL;
	temp->prev = NULL;
    return temp;
}

typeNODE* add(typeNODE* node, typeDATA data) {
    typeNODE* temp = (typeNODE*) malloc(sizeof (typeNODE));
    if (temp == NULL) {
        exit(0); // no memory available
    }
    temp->data = data;
    temp->next = node;
	temp->prev = NULL;
	node->prev = temp;
    return temp;
}


void add_at(typeNODE* node, typeDATA data) {
    typeNODE* temp = (typeNODE*) malloc(sizeof (typeNODE));
    if (temp == NULL) {
        exit(EXIT_FAILURE); // no memory available
    }
    temp->data = data;
    temp->next = node->next;
    node->next = temp;
}

void removeNode(typeNODE* node) {
	// This case is the node is NOT the head of the list
	if (!(node->prev == NULL))
	{
		node->prev->next = node->next;
	}
	// This case is the node is NOT the tail of the list
	if (!(node->next == NULL))
	{
		node->next->prev = node->prev;
	}
	
	//free(node->data.idName);
    //free(node);
}



typeNODE *free_list(typeNODE *head) {
    typeNODE *tmpPtr = head;
    typeNODE *followPtr;
    while (tmpPtr != NULL) {
        followPtr = tmpPtr;
        tmpPtr = tmpPtr->next;
        free(followPtr);
    }
    return NULL;
}
