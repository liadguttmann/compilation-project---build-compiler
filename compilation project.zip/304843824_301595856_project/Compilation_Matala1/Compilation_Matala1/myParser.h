#ifndef PARSER_H
#define PARSER_H
#include "Token.h"
#include "linkedList.h"

#define prevTypeNone 1
#define prevTypePointer 2
#define prevTypeArray 3
#define prevTypeVar 4

int match(int token_Kind);
void myParserMain();

void Parser_Program();
void Parser_Block();
void Parser_Definitions();
void Parser_Definitions_Tag();
void Parser_Definition();
void Parser_Var_Definition(char* id_name);
void Parser_Var_Definition_Tag(char* id_name);
void Parser_Type_Definition();
void Parser_Type_Indicator(char* type_name);
void Parser_Basic_Type(char* type_name, int prevType);
void Parser_Array_Type(char* type_name);
void Parser_Pointer_Type(char* type_name);
void Parser_Pointer_Type_Tag();
int Parser_Size();
int Parser_rel_op();
void Parser_Begin();
void Parser_Commands();
void Parser_Commands_Tag();
void Parser_Command();
void Parser_Reciver(typeDATA id_data);
void Parser_Reciver_Tag(typeDATA id_data);

//void Parser_Reciver_Tagaim(Token* currToken, typeDATA id_data);
int Parser_Expression(int expectedType);
void Parser_Expression_Tag(int expectedType, int checkPointer);

void recoveryFromError(int* followTokenKindArray, int followTokenKindArraySize);

void printTheRule(char *s);

#endif