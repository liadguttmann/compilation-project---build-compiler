#ifndef LL_H
#define LL_H

#define idTypeOfType 1
#define idTypeOfVar 2

#define idTypeTypeInteger 1
#define idTypeTypeReal 2
#define idTypeTypePointerInteger 3
#define idTypeTypePointerReal 4
#define idTypeTypeArrayInteger 5
#define idTypeTypeArrayReal 6
#define idTypeTypeVarInteger 7
#define idTypeTypeVarReal 8

typedef struct typedata{
    char* idName;
	int idType;
	int idTypeType;
	int	idScope;
} typeDATA;

typedef struct typenode {
    typeDATA data;
    struct typenode* next;
	struct typenode* prev;
} typeNODE;

typeNODE* init(typeDATA data);
typeNODE* add(typeNODE* node, typeDATA data);
void removeNode(typeNODE* node);
#endif